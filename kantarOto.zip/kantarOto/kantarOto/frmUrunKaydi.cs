﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient; 

namespace kantarOto
{
    public partial class frmUrunKaydi : Form
    {
        public frmUrunKaydi()
        {
            InitializeComponent();
        }
        public  void listele()
        {
            SqlDataAdapter da = new SqlDataAdapter("select ID as 'URUN NO', ad as 'URUN ADI' from tblurunler where durum=1", Baglanti.baglan());
            DataTable table = new DataTable();
            da.Fill(table);
            dataGridView1.DataSource = table;

            txtAd.Text = "";
            txtID.Text = "";
        }
        private void frmUrunKaydi_Load(object sender, EventArgs e)
        {
            listele(); 
        }

        private void button4_Click(object sender, EventArgs e)
        {
            listele(); 
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (txtAd.Text==""  )
            {
                MessageBox.Show("Ürün adını giriniz ", "Eksik Kayıt", MessageBoxButtons.OK, MessageBoxIcon.Warning);

            }
            else
            {
                SqlCommand komut = new SqlCommand("insert into tblUrunler (ad) values (@p1)", Baglanti.baglan()  );
                komut.Parameters.AddWithValue("@p1", txtAd.Text);
                if ( Baglanti.baglan().State != ConnectionState.Open )
                {
                    Baglanti.baglan().Open(); 
                }
                komut.ExecuteNonQuery();
                MessageBox.Show("Ürün kaydı tamam ", "Üran Kaydı", MessageBoxButtons.OK);
                txtAd.Text = ""; 
            }
            listele(); 
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            txtID.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
            txtAd.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString(); 

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (txtAd.Text == "")
            {
                MessageBox.Show("Ürün adını giriniz veya seçiniz ", "hatalı güncelleme işlemi", MessageBoxButtons.OK, MessageBoxIcon.Warning);

            }
            else
            {
                SqlCommand komut = new SqlCommand("update tblUrunler set ad= @p1 where ID = @p2", Baglanti.baglan());
                komut.Parameters.AddWithValue("@p1", txtAd.Text);
                komut.Parameters.AddWithValue("@p2", int.Parse( txtID.Text ) );

                if (Baglanti.baglan().State != ConnectionState.Open)
                {
                    Baglanti.baglan().Open();
                }
                komut.ExecuteNonQuery();
                MessageBox.Show("Ürün güncelleme işlemi tamam ", "Üran Kaydı", MessageBoxButtons.OK);
                txtAd.Text = "";
               
            }
            listele();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (txtAd.Text == "")
            {
                MessageBox.Show("Silmek istediğiniz ürünü seçiniz ", "hatalı silme işlemi", MessageBoxButtons.OK, MessageBoxIcon.Warning);

            }
            else
            {
                SqlCommand komut = new SqlCommand("update tblUrunler set durum= @p1 where ID = @p2", Baglanti.baglan());
                komut.Parameters.AddWithValue("@p1", 0 );
                komut.Parameters.AddWithValue("@p2", int.Parse(txtID.Text));

                if (Baglanti.baglan().State != ConnectionState.Open)
                {
                    Baglanti.baglan().Open();
                }
                komut.ExecuteNonQuery();
                MessageBox.Show("Ürün silme işlemi tamam ", "Üran Kaydı", MessageBoxButtons.OK);
                txtAd.Text = "";
                txtID.Text = ""; 

            }
            listele();
        }
    }
}
