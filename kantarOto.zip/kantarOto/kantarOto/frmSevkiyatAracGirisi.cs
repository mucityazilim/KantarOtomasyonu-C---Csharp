﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace kantarOto
{
    public partial class frmSevkiyatAracGirisi : Form
    {
        public frmSevkiyatAracGirisi()
        {
            InitializeComponent();
        }

        public void soforListele()
        {
            SqlCommand komut = new SqlCommand("select * from tblSoforler where durum=1", Baglanti.baglan());
            if (Baglanti.baglan().State != ConnectionState.Open)
            {
                Baglanti.baglan().Open();
            }

            SqlDataReader dr = komut.ExecuteReader();
            while (dr.Read())
            {
                cbSad.Items.Add(dr[0] + " : " + dr[1]);
            }
        }
        public void plakaListele()
        {
            SqlCommand komut = new SqlCommand("select * from tblAraclar where durum=1  ", Baglanti.baglan());
            if (Baglanti.baglan().State != ConnectionState.Open)
            {
                Baglanti.baglan().Open();
            }

            SqlDataReader dr = komut.ExecuteReader();
            while (dr.Read())
            {
                cbPlaka.Items.Add(dr[0]);
            }
        }

        public void firmaListele()
        {
            SqlCommand komut = new SqlCommand("select * from tblFirmalar where durum=1 ", Baglanti.baglan());
            if (Baglanti.baglan().State != ConnectionState.Open)
            {
                Baglanti.baglan().Open();
            }

            SqlDataReader dr = komut.ExecuteReader();
            while (dr.Read())
            {
                cbFa.Items.Add(dr[0] + " : " + dr[1]);
            }
        }

        public void urunListele()
        {
            SqlCommand komut = new SqlCommand("select * from tblUrunler where durum=1", Baglanti.baglan());
            if (Baglanti.baglan().State != ConnectionState.Open)
            {
                Baglanti.baglan().Open();
            }

            SqlDataReader dr = komut.ExecuteReader();
            while (dr.Read())
            {
                cbUa.Items.Add(dr[0] + " : " + dr[1]);
            }
        }

        public void memurListele()
        {
            SqlCommand komut = new SqlCommand("select * from tblKmemur where durum=1", Baglanti.baglan());
            if (Baglanti.baglan().State != ConnectionState.Open)
            {
                Baglanti.baglan().Open();
            }

            SqlDataReader dr = komut.ExecuteReader();
            while (dr.Read())
            {
                cbM.Items.Add(dr[0] + " : " + dr[1]);
            }
        }
        private void frmSevkiyatAracGirisi_Load(object sender, EventArgs e)
        {
            soforListele();
            firmaListele();
            urunListele();
            memurListele();
            plakaListele();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (cbSad.Text == "" || cbFa.Text == "" || cbUa.Text == "" || txtIlkT.Text == "" || cbPlaka.Text == "")
            {
                MessageBox.Show("Tüm alanları eksiksiz giriniz ", "Eksik Kayıt", MessageBoxButtons.OK, MessageBoxIcon.Warning);

            }
            else
            {
                string[] dizi;
                SqlCommand komut = new SqlCommand("insert into tblTartim (turu, plaka,  soforID, firmaID, urunID, ilkTartim, ikinciTartim, netTartim, girisTarih, cikisTarih, aciklama, durum, kMemur  ) values (@p1, @p2,  @p3, @p4, @p5, @p6, @p7, @p8, @p9 , @p10, @p11, @p12, @p3 )", Baglanti.baglan());
                komut.Parameters.AddWithValue("@p1", 2); // 2 = SEVKİYAT girişi 
                komut.Parameters.AddWithValue("@p2", cbPlaka.SelectedItem);
                dizi = cbFa.SelectedItem.ToString().Split(':');
                komut.Parameters.AddWithValue("@p3", int.Parse(dizi[0]));
                dizi = cbFa.SelectedItem.ToString().Split(':');
                komut.Parameters.AddWithValue("@p4", int.Parse(dizi[0]));
                dizi = cbUa.SelectedItem.ToString().Split(':');
                komut.Parameters.AddWithValue("@p5", int.Parse(dizi[0]));
                komut.Parameters.AddWithValue("@p6", txtIlkT.Text);
                komut.Parameters.AddWithValue("@p7", 0);
                komut.Parameters.AddWithValue("@p8", 0);
                komut.Parameters.AddWithValue("@p9", DateTime.Now.ToString());
                komut.Parameters.AddWithValue("@p10", DateTime.Now.ToString());
                komut.Parameters.AddWithValue("@p11", "Sevkiyat için araç girişi");
                komut.Parameters.AddWithValue("@p12", 1);
                dizi = cbM.SelectedItem.ToString().Split(':');
                komut.Parameters.AddWithValue("@p13", int.Parse(dizi[0]));
                if (Baglanti.baglan().State != ConnectionState.Open)
                {
                    Baglanti.baglan().Open();
                }
                komut.ExecuteNonQuery();
                MessageBox.Show("Araç tartım kaydı tamam ", "Tartım Kaydı", MessageBoxButtons.OK);
                cbSad.Text = "";
                cbFa.Text = "";
                cbUa.Text = "";
                cbM.Text = "";
                cbPlaka.Text = "";

            }
        }
    }
}
