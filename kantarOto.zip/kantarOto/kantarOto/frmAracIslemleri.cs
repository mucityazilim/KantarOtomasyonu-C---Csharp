﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace kantarOto
{
    public partial class frmAracIslemleri : Form
    {
        public frmAracIslemleri()
        {
            InitializeComponent();
        }
        public void listele()
        {
            SqlDataAdapter da = new SqlDataAdapter("select plaka as 'PLAKA', cinsi as 'CİNSİ', kapasitesi as 'KAPASİTE' from tblAraclar where durum=1", Baglanti.baglan());
            DataTable table = new DataTable();
            da.Fill(table);
            dataGridView1.DataSource = table;

            txtPlaka.Text = "";
            txtCins.Text = "";
            txtKap.Text = "";
        }

        private void frmAracIslemleri_Load(object sender, EventArgs e)
        {
            listele();

        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            txtPlaka.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
            txtCins.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
            txtKap.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();

        }

        private void button4_Click(object sender, EventArgs e)
        {
            listele();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (txtPlaka.Text == "" || txtCins.Text == "" || txtKap.Text == "")
            {
                MessageBox.Show("Araç bilgilerini eksiksiz giriniz ", "Eksik Kayıt", MessageBoxButtons.OK, MessageBoxIcon.Warning);

            }
            else
            {
                SqlCommand komut = new SqlCommand("insert into tblAraclar (plaka, cinsi, kapasitesi ) values (@p1, @p2, @p3)", Baglanti.baglan());
                komut.Parameters.AddWithValue("@p1", txtPlaka.Text);
                komut.Parameters.AddWithValue("@p2", txtCins.Text);
                komut.Parameters.AddWithValue("@p3", txtKap.Text);

                if (Baglanti.baglan().State != ConnectionState.Open)
                {
                    Baglanti.baglan().Open();
                }
                komut.ExecuteNonQuery();
                MessageBox.Show("Araç kaydı tamam ", "Araç Kaydı", MessageBoxButtons.OK);

            }
            listele();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (txtPlaka.Text == "" || txtCins.Text == "" || txtKap.Text == "")
            {
                MessageBox.Show("Araç plakasını giriniz veya seçiniz ", "hatalı güncelleme işlemi", MessageBoxButtons.OK, MessageBoxIcon.Warning);

            }
            else
            {
                SqlCommand komut = new SqlCommand("update tblAraclar set cinsi= @p1, kapasitesi=@p2 where plaka = @p3", Baglanti.baglan());
                komut.Parameters.AddWithValue("@p1", txtCins.Text);
                komut.Parameters.AddWithValue("@p2", txtKap.Text);
                komut.Parameters.AddWithValue("@p3", txtPlaka.Text);

                if (Baglanti.baglan().State != ConnectionState.Open)
                {
                    Baglanti.baglan().Open();
                }
                int sonuc= komut.ExecuteNonQuery();
                if(sonuc== 1)
                MessageBox.Show("Araç güncelleme işlemi tamam ", "Araç güncelleme", MessageBoxButtons.OK);
                else
                    MessageBox.Show("Araç güncelleme işleminde bir hata var, lütfen plaka bilgisini kontrol ederek tekrar deneyiniz", "Araç güncelleme Hatası ", MessageBoxButtons.OK, MessageBoxIcon.Warning);


            }
            listele();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (txtPlaka.Text == "" || txtCins.Text == "" || txtKap.Text == "")
            {
                MessageBox.Show("Silmek istediğiniz aracı seçiniz ", "hatalı silme işlemi", MessageBoxButtons.OK, MessageBoxIcon.Warning);

            }
            else
            {
                SqlCommand komut = new SqlCommand("update tblAraclar set durum= @p1 where plaka = @p2", Baglanti.baglan());
                komut.Parameters.AddWithValue("@p1", 0);
                komut.Parameters.AddWithValue("@p2", txtPlaka.Text);

                if (Baglanti.baglan().State != ConnectionState.Open)
                {
                    Baglanti.baglan().Open();
                }
                int sonuc = komut.ExecuteNonQuery();
                if (sonuc == 1)
                    MessageBox.Show("Araç silme işlemi tamam ", "Araç Silme ", MessageBoxButtons.OK);
                else
                    MessageBox.Show("Araç silme işleminde bir hata var, lütfen plaka bilgisini kontrol ederek tekrar deneyiniz", "Araç Silme Hatası ", MessageBoxButtons.OK, MessageBoxIcon.Warning );



            }
            listele();
        }
    }
}
