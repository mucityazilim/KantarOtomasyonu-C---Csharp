﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace kantarOto
{
    public partial class frmStokIslemleri : Form
    {
        public frmStokIslemleri()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            frmStokAracGirisi frm = new frmStokAracGirisi();
            frm.Show(); 
        }

        private void button3_Click(object sender, EventArgs e)
        {
            frmStokBekleyenAraclar frm = new frmStokBekleyenAraclar();
            frm.Show(); 


        }

        private void button2_Click(object sender, EventArgs e)
        {
            frmStokAracCikisi frm = new frmStokAracCikisi();
            frm.Show(); 
        }

        private void button4_Click(object sender, EventArgs e)
        {
            frmStokRaporlari frm = new frmStokRaporlari();
            frm.Show(); 
        }

        private void frmStokIslemleri_Load(object sender, EventArgs e)
        {

        }
    }
}
