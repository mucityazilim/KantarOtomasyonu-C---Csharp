﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace kantarOto
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text=="" || textBox2.Text=="")
            {
                MessageBox.Show("Lütfen Kullanıcı Adı ve Parolanızı Giriniz ", "Eksik Giriş");
            }
            else if (textBox1.Text=="admin" && textBox2.Text=="123" )
            {
                frmAnaMenu frm = new frmAnaMenu();
                frm.Show(); 
            }
            else
            {
                MessageBox.Show("Kullanıcı Adı/ Parola Hatalı", "Hatalı İşlem");
            }
            textBox1.Text = "";
            textBox2.Text = ""; 
        }
    }
}
