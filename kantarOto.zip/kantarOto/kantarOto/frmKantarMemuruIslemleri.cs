﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient; 


namespace kantarOto
{
    public partial class frmKantarMemuruIslemleri : Form
    {
        public frmKantarMemuruIslemleri()
        {
            InitializeComponent();
        }

        public void listele()
        {
            SqlDataAdapter da = new SqlDataAdapter("select ID as 'MEMUR NO', adSoyad as 'AD/SOYAD',  tc as 'TC No.', adres as 'ADRES', tel as 'TELEFON'  from tblKmemur where durum=1", Baglanti.baglan());
            DataTable table = new DataTable();
            da.Fill(table);
            dataGridView1.DataSource = table;
            txtAd.Text = "";
            txtTc.Text = ""; 
            txtAdres.Text = "";
            txtTel.Text = "";
            txtID.Text = "";

        }

        private void frmKantarMemuruIslemleri_Load(object sender, EventArgs e)
        {
            listele(); 

        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            txtID.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
            txtAd.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
            txtTc.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
            txtAdres.Text = dataGridView1.CurrentRow.Cells[3].Value.ToString();
            txtTel.Text = dataGridView1.CurrentRow.Cells[4].Value.ToString();

        }

        private void button4_Click(object sender, EventArgs e)
        {
            listele(); 
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (txtAd.Text == ""  || txtTc.Text=="" || txtAdres.Text == "" || txtTel.Text == "")
            {
                MessageBox.Show("Memur bilgilerini eksiksiz giriniz ", "Eksik Kayıt", MessageBoxButtons.OK, MessageBoxIcon.Warning);

            }
            else
            {
                SqlCommand komut = new SqlCommand("insert into tblKmemur (adSoyad, tc,  adres, tel ) values (@p1, @p2, @p3, @p4)", Baglanti.baglan());
                komut.Parameters.AddWithValue("@p1", txtAd.Text);
                komut.Parameters.AddWithValue("@p2", txtTc.Text);
                komut.Parameters.AddWithValue("@p3", txtAdres.Text);
                komut.Parameters.AddWithValue("@p4", txtTel.Text);

                if (Baglanti.baglan().State != ConnectionState.Open)
                {
                    Baglanti.baglan().Open();
                }
                komut.ExecuteNonQuery();
                MessageBox.Show("Memur kaydı tamam ", "Memur Kaydı", MessageBoxButtons.OK);
                
            }
            listele();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (txtAd.Text == "" || txtTc.Text == "" || txtAdres.Text == "" || txtTel.Text == "")
            {
                MessageBox.Show("Memur adını giriniz veya seçiniz ", "hatalı güncelleme işlemi", MessageBoxButtons.OK, MessageBoxIcon.Warning);

            }
            else
            {
                SqlCommand komut = new SqlCommand("update tblKmemur set adSoyad= @p1, tc=@p2,  adres=@p3, tel =@p4 where ID = @p5", Baglanti.baglan());
                komut.Parameters.AddWithValue("@p1", txtAd.Text);
                komut.Parameters.AddWithValue("@p2", txtTc.Text);
                komut.Parameters.AddWithValue("@p3", txtAdres.Text);
                komut.Parameters.AddWithValue("@p4", txtTel.Text);
                komut.Parameters.AddWithValue("@p5", int.Parse(txtID.Text));

                if (Baglanti.baglan().State != ConnectionState.Open)
                {
                    Baglanti.baglan().Open();
                }
                komut.ExecuteNonQuery();
                MessageBox.Show("Memur güncelleme işlemi tamam ", "Memur güncelleme", MessageBoxButtons.OK);



            }
            listele();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (txtAd.Text == "" || txtID.Text=="" )
            {
                MessageBox.Show("Silmek istediğiniz kişiyi seçiniz ", "hatalı silme işlemi", MessageBoxButtons.OK, MessageBoxIcon.Warning);

            }
            else
            {
                SqlCommand komut = new SqlCommand("update tblKmemur set durum= @p1 where ID = @p2", Baglanti.baglan());
                komut.Parameters.AddWithValue("@p1", 0);
                komut.Parameters.AddWithValue("@p2", int.Parse(txtID.Text));

                if (Baglanti.baglan().State != ConnectionState.Open)
                {
                    Baglanti.baglan().Open();
                }
                komut.ExecuteNonQuery();
                MessageBox.Show("Memur silme işlemi tamam ", "Memur Silme ", MessageBoxButtons.OK);


            }
            listele();
        }
    }
}
