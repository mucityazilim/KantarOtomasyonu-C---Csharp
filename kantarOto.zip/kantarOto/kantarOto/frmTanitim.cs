﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace kantarOto
{
    public partial class frmTanitim : Form
    {
        public frmTanitim()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            frmUrunKaydi frm = new frmUrunKaydi();
            frm.Show(); 
        }

        private void button2_Click(object sender, EventArgs e)
        {
            frmFirmaIslemleri frm = new frmFirmaIslemleri();
            frm.Show(); 
        }

        private void button3_Click(object sender, EventArgs e)
        {
            frmSoforIslemleri frm = new frmSoforIslemleri();
            frm.Show(); 
        }

        private void button4_Click(object sender, EventArgs e)
        {
            frmKantarMemuruIslemleri frm = new frmKantarMemuruIslemleri();
            frm.Show(); 
        }

        private void button5_Click(object sender, EventArgs e)
        {
            frmAracIslemleri frm = new frmAracIslemleri();
            frm.Show(); 
        }

        private void frmTanitim_Load(object sender, EventArgs e)
        {

        }
    }
}
