﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient; 


namespace kantarOto
{
    public partial class frmStokRaporlari : Form
    {
        public frmStokRaporlari()
        {
            InitializeComponent();
        }

        void listele()
        {
            SqlDataAdapter da = new SqlDataAdapter("select ID as 'NO', plaka as ' Plaka ', girisTarih as 'Giris Tarih/Saat', cikisTarih as 'Çıkış Tarih/Saat', urunID as 'Ürün No', netTartim as 'Net Tartım (kg)' from tblTartim where durum=2 and turu=1", Baglanti.baglan());
            DataTable table = new DataTable();
            da.Fill(table);
            dataGridView1.DataSource = table;
        }

        private void frmStokRaporlari_Load(object sender, EventArgs e)
        {
            listele(); 

        }
    }
}
