﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient; 
namespace kantarOto
{
    class Baglanti
    {
        public static SqlConnection baglan()
        {
            SqlConnection con = new SqlConnection("server= .\\SQLEXPRESS ; initial catalog = kantarDB; integrated security = sspi");
            // yukarıdaki bağlantı adresine  " .\\SQLEXPRESS "  kendi adresinizi yazınız..
            con.Open();
            return con; 
        }
    }
}
