﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient; 


namespace kantarOto
{
    public partial class frmSevkiyatAracCikisi : Form
    {
        public frmSevkiyatAracCikisi()
        {
            InitializeComponent();
        }

        void listele()
        {
            SqlDataAdapter da = new SqlDataAdapter("select ID as 'NO', plaka as ' Plaka ', girisTarih as 'Giris Tarih/Saat', ilkTartim as'İlk Tartım (kg)' from tblTartim where durum=1 and turu=2", Baglanti.baglan());
            DataTable table = new DataTable();
            da.Fill(table);
            dataGridView1.DataSource = table;
            txtNo.Text = "";
            txtPlaka.Text = "";
            txtSonTartim.Text = "";
        }


        private void frmSevkiyatAracCikisi_Load(object sender, EventArgs e)
        {
            listele(); 
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            txtNo.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
            txtPlaka.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
            txtSonTartim.Text = "";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (txtPlaka.Text == "")
            {
                MessageBox.Show("Araç plakasını seçiniz ", "hatalı işlem", MessageBoxButtons.OK, MessageBoxIcon.Warning);

            }
            else if (txtSonTartim.Text == "")
            {
                MessageBox.Show("Son tartımı giriniz ", "hatalı işlem", MessageBoxButtons.OK, MessageBoxIcon.Warning);

            }

            else
            {
                SqlCommand komut = new SqlCommand("update tblTartim set ikinciTartim= @p1, netTartim=  @p1 - ilkTartim,  cikisTarih=@p3, aciklama= @p4,   durum = @p5 where ID = @p6", Baglanti.baglan());
                komut.Parameters.AddWithValue("@p1", txtSonTartim.Text);
                //komut.Parameters.AddWithValue("@p2", int.Parse( "ilkTartim - ikinciTartim" )   );
                komut.Parameters.AddWithValue("@p3", DateTime.Now);
                komut.Parameters.AddWithValue("@p4", "sevkiyat için dolum  işlemi tamamlandı");
                komut.Parameters.AddWithValue("@p5", 2);
                komut.Parameters.AddWithValue("@p6", txtNo.Text);

                if (Baglanti.baglan().State != ConnectionState.Open)
                {
                    Baglanti.baglan().Open();
                }
                komut.ExecuteNonQuery();
                MessageBox.Show("Son tartım işlemi tamam ", "Araç çıkış işlemi ", MessageBoxButtons.OK);
            }
            listele();
        }
    }
}
